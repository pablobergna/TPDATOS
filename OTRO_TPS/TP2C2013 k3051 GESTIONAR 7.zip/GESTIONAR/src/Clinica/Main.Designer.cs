﻿namespace Clinica
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.consultaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrarResultadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrarLlegadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.altaRolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bajaRolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarRolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarRolesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.altaUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bajaUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afiliadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.altaAfiliadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bajaAfiliadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarAfiliadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarAfiliadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profesionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.altaProfesionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bajaProfesionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarProfesionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarProfesionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.especialidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.altaEspecialidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bajaEspecialidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarEspecialidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarEspecialidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.planToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.altaPlanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bajaPlanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarPlanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pedidoTurnoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelarAtencionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bonosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comprarBonosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estadisticasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bonosFarmaciaVencidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.especialidadesConCancelacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bonosFarmaciaRecetadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afiliadosQueUsaronPeroNoCompraronToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultaToolStripMenuItem,
            this.aBMToolStripMenuItem,
            this.usuarioToolStripMenuItem,
            this.afiliadoToolStripMenuItem,
            this.profesionalToolStripMenuItem,
            this.especialidadesToolStripMenuItem,
            this.planToolStripMenuItem,
            this.agendaToolStripMenuItem,
            this.bonosToolStripMenuItem,
            this.estadisticasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(633, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // consultaToolStripMenuItem
            // 
            this.consultaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrarResultadoToolStripMenuItem,
            this.registrarLlegadaToolStripMenuItem});
            this.consultaToolStripMenuItem.Name = "consultaToolStripMenuItem";
            this.consultaToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.consultaToolStripMenuItem.Text = "Consulta";
            this.consultaToolStripMenuItem.Visible = false;
            // 
            // registrarResultadoToolStripMenuItem
            // 
            this.registrarResultadoToolStripMenuItem.Name = "registrarResultadoToolStripMenuItem";
            this.registrarResultadoToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.registrarResultadoToolStripMenuItem.Text = "Registrar resultado";
            this.registrarResultadoToolStripMenuItem.Visible = false;
            this.registrarResultadoToolStripMenuItem.Click += new System.EventHandler(this.registrarResultadoToolStripMenuItem_Click);
            // 
            // registrarLlegadaToolStripMenuItem
            // 
            this.registrarLlegadaToolStripMenuItem.Name = "registrarLlegadaToolStripMenuItem";
            this.registrarLlegadaToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.registrarLlegadaToolStripMenuItem.Text = "Registrar Llegada";
            this.registrarLlegadaToolStripMenuItem.Visible = false;
            this.registrarLlegadaToolStripMenuItem.Click += new System.EventHandler(this.registrarLlegadaToolStripMenuItem_Click);
            // 
            // aBMToolStripMenuItem
            // 
            this.aBMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.altaRolToolStripMenuItem,
            this.bajaRolToolStripMenuItem,
            this.modificarRolToolStripMenuItem,
            this.listarRolesToolStripMenuItem});
            this.aBMToolStripMenuItem.Name = "aBMToolStripMenuItem";
            this.aBMToolStripMenuItem.Size = new System.Drawing.Size(34, 20);
            this.aBMToolStripMenuItem.Text = "Rol";
            this.aBMToolStripMenuItem.Visible = false;
            // 
            // altaRolToolStripMenuItem
            // 
            this.altaRolToolStripMenuItem.Name = "altaRolToolStripMenuItem";
            this.altaRolToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.altaRolToolStripMenuItem.Text = "Alta Rol";
            this.altaRolToolStripMenuItem.Visible = false;
            this.altaRolToolStripMenuItem.Click += new System.EventHandler(this.altaRolToolStripMenuItem_Click);
            // 
            // bajaRolToolStripMenuItem
            // 
            this.bajaRolToolStripMenuItem.Name = "bajaRolToolStripMenuItem";
            this.bajaRolToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.bajaRolToolStripMenuItem.Text = "Baja Rol";
            this.bajaRolToolStripMenuItem.Visible = false;
            this.bajaRolToolStripMenuItem.Click += new System.EventHandler(this.bajaRolToolStripMenuItem_Click);
            // 
            // modificarRolToolStripMenuItem
            // 
            this.modificarRolToolStripMenuItem.Name = "modificarRolToolStripMenuItem";
            this.modificarRolToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.modificarRolToolStripMenuItem.Text = "Modificar Rol";
            this.modificarRolToolStripMenuItem.Visible = false;
            this.modificarRolToolStripMenuItem.Click += new System.EventHandler(this.modificarRolToolStripMenuItem_Click);
            // 
            // listarRolesToolStripMenuItem
            // 
            this.listarRolesToolStripMenuItem.Name = "listarRolesToolStripMenuItem";
            this.listarRolesToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.listarRolesToolStripMenuItem.Text = "Listar Roles";
            this.listarRolesToolStripMenuItem.Visible = false;
            this.listarRolesToolStripMenuItem.Click += new System.EventHandler(this.listarRolesToolStripMenuItem_Click);
            // 
            // usuarioToolStripMenuItem
            // 
            this.usuarioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.altaUsuarioToolStripMenuItem,
            this.bajaUsuarioToolStripMenuItem,
            this.modificarToolStripMenuItem,
            this.listarUsuariosToolStripMenuItem});
            this.usuarioToolStripMenuItem.Name = "usuarioToolStripMenuItem";
            this.usuarioToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.usuarioToolStripMenuItem.Text = "Usuario";
            this.usuarioToolStripMenuItem.Visible = false;
            // 
            // altaUsuarioToolStripMenuItem
            // 
            this.altaUsuarioToolStripMenuItem.Name = "altaUsuarioToolStripMenuItem";
            this.altaUsuarioToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.altaUsuarioToolStripMenuItem.Text = "Alta Usuario";
            this.altaUsuarioToolStripMenuItem.Visible = false;
            this.altaUsuarioToolStripMenuItem.Click += new System.EventHandler(this.altaUsuarioToolStripMenuItem_Click);
            // 
            // bajaUsuarioToolStripMenuItem
            // 
            this.bajaUsuarioToolStripMenuItem.Name = "bajaUsuarioToolStripMenuItem";
            this.bajaUsuarioToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.bajaUsuarioToolStripMenuItem.Text = "Baja Usuario";
            this.bajaUsuarioToolStripMenuItem.Visible = false;
            this.bajaUsuarioToolStripMenuItem.Click += new System.EventHandler(this.bajaUsuarioToolStripMenuItem_Click);
            // 
            // modificarToolStripMenuItem
            // 
            this.modificarToolStripMenuItem.Name = "modificarToolStripMenuItem";
            this.modificarToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.modificarToolStripMenuItem.Text = "Modificar Usuario";
            this.modificarToolStripMenuItem.Visible = false;
            this.modificarToolStripMenuItem.Click += new System.EventHandler(this.modificarToolStripMenuItem_Click);
            // 
            // listarUsuariosToolStripMenuItem
            // 
            this.listarUsuariosToolStripMenuItem.Name = "listarUsuariosToolStripMenuItem";
            this.listarUsuariosToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.listarUsuariosToolStripMenuItem.Text = "Listar Usuarios";
            this.listarUsuariosToolStripMenuItem.Visible = false;
            this.listarUsuariosToolStripMenuItem.Click += new System.EventHandler(this.listarUsuariosToolStripMenuItem_Click);
            // 
            // afiliadoToolStripMenuItem
            // 
            this.afiliadoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.altaAfiliadoToolStripMenuItem,
            this.bajaAfiliadoToolStripMenuItem,
            this.modificarAfiliadoToolStripMenuItem,
            this.listarAfiliadosToolStripMenuItem});
            this.afiliadoToolStripMenuItem.Name = "afiliadoToolStripMenuItem";
            this.afiliadoToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.afiliadoToolStripMenuItem.Text = "Afiliado";
            this.afiliadoToolStripMenuItem.Visible = false;
            // 
            // altaAfiliadoToolStripMenuItem
            // 
            this.altaAfiliadoToolStripMenuItem.Name = "altaAfiliadoToolStripMenuItem";
            this.altaAfiliadoToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.altaAfiliadoToolStripMenuItem.Text = "Alta Afiliado";
            this.altaAfiliadoToolStripMenuItem.Visible = false;
            this.altaAfiliadoToolStripMenuItem.Click += new System.EventHandler(this.altaAfiliadoToolStripMenuItem_Click);
            // 
            // bajaAfiliadoToolStripMenuItem
            // 
            this.bajaAfiliadoToolStripMenuItem.Name = "bajaAfiliadoToolStripMenuItem";
            this.bajaAfiliadoToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.bajaAfiliadoToolStripMenuItem.Text = "Baja Afiliado";
            this.bajaAfiliadoToolStripMenuItem.Visible = false;
            this.bajaAfiliadoToolStripMenuItem.Click += new System.EventHandler(this.bajaAfiliadoToolStripMenuItem_Click);
            // 
            // modificarAfiliadoToolStripMenuItem
            // 
            this.modificarAfiliadoToolStripMenuItem.Name = "modificarAfiliadoToolStripMenuItem";
            this.modificarAfiliadoToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.modificarAfiliadoToolStripMenuItem.Text = "Modificar Afiliado";
            this.modificarAfiliadoToolStripMenuItem.Visible = false;
            this.modificarAfiliadoToolStripMenuItem.Click += new System.EventHandler(this.modificarAfiliadoToolStripMenuItem_Click);
            // 
            // listarAfiliadosToolStripMenuItem
            // 
            this.listarAfiliadosToolStripMenuItem.Name = "listarAfiliadosToolStripMenuItem";
            this.listarAfiliadosToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.listarAfiliadosToolStripMenuItem.Text = "Listar Afiliados";
            this.listarAfiliadosToolStripMenuItem.Visible = false;
            this.listarAfiliadosToolStripMenuItem.Click += new System.EventHandler(this.listarAfiliadosToolStripMenuItem_Click);
            // 
            // profesionalToolStripMenuItem
            // 
            this.profesionalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.altaProfesionalToolStripMenuItem,
            this.bajaProfesionalToolStripMenuItem,
            this.modificarProfesionalToolStripMenuItem,
            this.listarProfesionalToolStripMenuItem});
            this.profesionalToolStripMenuItem.Name = "profesionalToolStripMenuItem";
            this.profesionalToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.profesionalToolStripMenuItem.Text = "Profesional";
            this.profesionalToolStripMenuItem.Visible = false;
            // 
            // altaProfesionalToolStripMenuItem
            // 
            this.altaProfesionalToolStripMenuItem.Name = "altaProfesionalToolStripMenuItem";
            this.altaProfesionalToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.altaProfesionalToolStripMenuItem.Text = "Alta Profesional";
            this.altaProfesionalToolStripMenuItem.Visible = false;
            this.altaProfesionalToolStripMenuItem.Click += new System.EventHandler(this.altaProfesionalToolStripMenuItem_Click);
            // 
            // bajaProfesionalToolStripMenuItem
            // 
            this.bajaProfesionalToolStripMenuItem.Name = "bajaProfesionalToolStripMenuItem";
            this.bajaProfesionalToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.bajaProfesionalToolStripMenuItem.Text = "Baja Profesional";
            this.bajaProfesionalToolStripMenuItem.Visible = false;
            this.bajaProfesionalToolStripMenuItem.Click += new System.EventHandler(this.bajaProfesionalToolStripMenuItem_Click);
            // 
            // modificarProfesionalToolStripMenuItem
            // 
            this.modificarProfesionalToolStripMenuItem.Name = "modificarProfesionalToolStripMenuItem";
            this.modificarProfesionalToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.modificarProfesionalToolStripMenuItem.Text = "Modificar Profesional";
            this.modificarProfesionalToolStripMenuItem.Visible = false;
            this.modificarProfesionalToolStripMenuItem.Click += new System.EventHandler(this.modificarProfesionalToolStripMenuItem_Click);
            // 
            // listarProfesionalToolStripMenuItem
            // 
            this.listarProfesionalToolStripMenuItem.Name = "listarProfesionalToolStripMenuItem";
            this.listarProfesionalToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.listarProfesionalToolStripMenuItem.Text = "Listar Profesional";
            this.listarProfesionalToolStripMenuItem.Visible = false;
            this.listarProfesionalToolStripMenuItem.Click += new System.EventHandler(this.listarProfesionalToolStripMenuItem_Click);
            // 
            // especialidadesToolStripMenuItem
            // 
            this.especialidadesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.altaEspecialidadesToolStripMenuItem,
            this.bajaEspecialidadesToolStripMenuItem,
            this.modificarEspecialidadesToolStripMenuItem,
            this.listarEspecialidadesToolStripMenuItem});
            this.especialidadesToolStripMenuItem.Name = "especialidadesToolStripMenuItem";
            this.especialidadesToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.especialidadesToolStripMenuItem.Text = "Especialidades";
            this.especialidadesToolStripMenuItem.Visible = false;
            // 
            // altaEspecialidadesToolStripMenuItem
            // 
            this.altaEspecialidadesToolStripMenuItem.Name = "altaEspecialidadesToolStripMenuItem";
            this.altaEspecialidadesToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.altaEspecialidadesToolStripMenuItem.Text = "Alta Especialidades";
            this.altaEspecialidadesToolStripMenuItem.Visible = false;
            this.altaEspecialidadesToolStripMenuItem.Click += new System.EventHandler(this.altaEspecialidadesToolStripMenuItem_Click);
            // 
            // bajaEspecialidadesToolStripMenuItem
            // 
            this.bajaEspecialidadesToolStripMenuItem.Name = "bajaEspecialidadesToolStripMenuItem";
            this.bajaEspecialidadesToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.bajaEspecialidadesToolStripMenuItem.Text = "Baja Especialidades";
            this.bajaEspecialidadesToolStripMenuItem.Visible = false;
            this.bajaEspecialidadesToolStripMenuItem.Click += new System.EventHandler(this.bajaEspecialidadesToolStripMenuItem_Click);
            // 
            // modificarEspecialidadesToolStripMenuItem
            // 
            this.modificarEspecialidadesToolStripMenuItem.Name = "modificarEspecialidadesToolStripMenuItem";
            this.modificarEspecialidadesToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.modificarEspecialidadesToolStripMenuItem.Text = "Modificar Especialidades";
            this.modificarEspecialidadesToolStripMenuItem.Visible = false;
            this.modificarEspecialidadesToolStripMenuItem.Click += new System.EventHandler(this.modificarEspecialidadesToolStripMenuItem_Click);
            // 
            // listarEspecialidadesToolStripMenuItem
            // 
            this.listarEspecialidadesToolStripMenuItem.Name = "listarEspecialidadesToolStripMenuItem";
            this.listarEspecialidadesToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.listarEspecialidadesToolStripMenuItem.Text = "Listar Especialidades";
            this.listarEspecialidadesToolStripMenuItem.Visible = false;
            this.listarEspecialidadesToolStripMenuItem.Click += new System.EventHandler(this.listarEspecialidadesToolStripMenuItem_Click);
            // 
            // planToolStripMenuItem
            // 
            this.planToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.altaPlanToolStripMenuItem,
            this.bajaPlanToolStripMenuItem,
            this.mToolStripMenuItem,
            this.listarPlanToolStripMenuItem});
            this.planToolStripMenuItem.Name = "planToolStripMenuItem";
            this.planToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.planToolStripMenuItem.Text = "Plan";
            this.planToolStripMenuItem.Visible = false;
            // 
            // altaPlanToolStripMenuItem
            // 
            this.altaPlanToolStripMenuItem.Name = "altaPlanToolStripMenuItem";
            this.altaPlanToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.altaPlanToolStripMenuItem.Text = "Alta Plan";
            this.altaPlanToolStripMenuItem.Visible = false;
            this.altaPlanToolStripMenuItem.Click += new System.EventHandler(this.altaPlanToolStripMenuItem_Click);
            // 
            // bajaPlanToolStripMenuItem
            // 
            this.bajaPlanToolStripMenuItem.Name = "bajaPlanToolStripMenuItem";
            this.bajaPlanToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.bajaPlanToolStripMenuItem.Text = "Baja Plan";
            this.bajaPlanToolStripMenuItem.Visible = false;
            this.bajaPlanToolStripMenuItem.Click += new System.EventHandler(this.bajaPlanToolStripMenuItem_Click);
            // 
            // mToolStripMenuItem
            // 
            this.mToolStripMenuItem.Name = "mToolStripMenuItem";
            this.mToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.mToolStripMenuItem.Text = "Modificar Plan";
            this.mToolStripMenuItem.Visible = false;
            this.mToolStripMenuItem.Click += new System.EventHandler(this.mToolStripMenuItem_Click);
            // 
            // listarPlanToolStripMenuItem
            // 
            this.listarPlanToolStripMenuItem.Name = "listarPlanToolStripMenuItem";
            this.listarPlanToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.listarPlanToolStripMenuItem.Text = "Listar Plan";
            this.listarPlanToolStripMenuItem.Visible = false;
            this.listarPlanToolStripMenuItem.Click += new System.EventHandler(this.listarPlanToolStripMenuItem_Click);
            // 
            // agendaToolStripMenuItem
            // 
            this.agendaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrarToolStripMenuItem,
            this.pedidoTurnoToolStripMenuItem,
            this.cancelarAtencionToolStripMenuItem});
            this.agendaToolStripMenuItem.Name = "agendaToolStripMenuItem";
            this.agendaToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.agendaToolStripMenuItem.Text = "Turno";
            this.agendaToolStripMenuItem.Visible = false;
            // 
            // registrarToolStripMenuItem
            // 
            this.registrarToolStripMenuItem.Name = "registrarToolStripMenuItem";
            this.registrarToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.registrarToolStripMenuItem.Text = "Registrar Agenda";
            this.registrarToolStripMenuItem.Visible = false;
            this.registrarToolStripMenuItem.Click += new System.EventHandler(this.registrarToolStripMenuItem_Click);
            // 
            // pedidoTurnoToolStripMenuItem
            // 
            this.pedidoTurnoToolStripMenuItem.Name = "pedidoTurnoToolStripMenuItem";
            this.pedidoTurnoToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.pedidoTurnoToolStripMenuItem.Text = "Pedido Turno";
            this.pedidoTurnoToolStripMenuItem.Visible = false;
            this.pedidoTurnoToolStripMenuItem.Click += new System.EventHandler(this.pedidoTurnoToolStripMenuItem_Click);
            // 
            // cancelarAtencionToolStripMenuItem
            // 
            this.cancelarAtencionToolStripMenuItem.Name = "cancelarAtencionToolStripMenuItem";
            this.cancelarAtencionToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.cancelarAtencionToolStripMenuItem.Text = "Cancelar Atencion";
            this.cancelarAtencionToolStripMenuItem.Visible = false;
            this.cancelarAtencionToolStripMenuItem.Click += new System.EventHandler(this.cancelarAtencionToolStripMenuItem_Click);
            // 
            // bonosToolStripMenuItem
            // 
            this.bonosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comprarBonosToolStripMenuItem});
            this.bonosToolStripMenuItem.Name = "bonosToolStripMenuItem";
            this.bonosToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.bonosToolStripMenuItem.Text = "Bonos";
            this.bonosToolStripMenuItem.Visible = false;
            // 
            // comprarBonosToolStripMenuItem
            // 
            this.comprarBonosToolStripMenuItem.Name = "comprarBonosToolStripMenuItem";
            this.comprarBonosToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.comprarBonosToolStripMenuItem.Text = "Comprar Bonos";
            this.comprarBonosToolStripMenuItem.Visible = false;
            this.comprarBonosToolStripMenuItem.Click += new System.EventHandler(this.comprarBonosToolStripMenuItem_Click);
            // 
            // estadisticasToolStripMenuItem
            // 
            this.estadisticasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bonosFarmaciaVencidosToolStripMenuItem,
            this.especialidadesConCancelacionesToolStripMenuItem,
            this.bonosFarmaciaRecetadosToolStripMenuItem,
            this.afiliadosQueUsaronPeroNoCompraronToolStripMenuItem});
            this.estadisticasToolStripMenuItem.Name = "estadisticasToolStripMenuItem";
            this.estadisticasToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.estadisticasToolStripMenuItem.Text = "Estadisticas";
            this.estadisticasToolStripMenuItem.Visible = false;
            // 
            // bonosFarmaciaVencidosToolStripMenuItem
            // 
            this.bonosFarmaciaVencidosToolStripMenuItem.Name = "bonosFarmaciaVencidosToolStripMenuItem";
            this.bonosFarmaciaVencidosToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.bonosFarmaciaVencidosToolStripMenuItem.Text = "Bonos Farmacia Vencidos";
            this.bonosFarmaciaVencidosToolStripMenuItem.Visible = false;
            this.bonosFarmaciaVencidosToolStripMenuItem.Click += new System.EventHandler(this.bonosFarmaciaVencidosToolStripMenuItem_Click);
            // 
            // especialidadesConCancelacionesToolStripMenuItem
            // 
            this.especialidadesConCancelacionesToolStripMenuItem.Name = "especialidadesConCancelacionesToolStripMenuItem";
            this.especialidadesConCancelacionesToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.especialidadesConCancelacionesToolStripMenuItem.Text = "Especialidades con cancelaciones";
            this.especialidadesConCancelacionesToolStripMenuItem.Visible = false;
            this.especialidadesConCancelacionesToolStripMenuItem.Click += new System.EventHandler(this.especialidadesConCancelacionesToolStripMenuItem_Click);
            // 
            // bonosFarmaciaRecetadosToolStripMenuItem
            // 
            this.bonosFarmaciaRecetadosToolStripMenuItem.Name = "bonosFarmaciaRecetadosToolStripMenuItem";
            this.bonosFarmaciaRecetadosToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.bonosFarmaciaRecetadosToolStripMenuItem.Text = "Bonos Farmacia Recetados";
            this.bonosFarmaciaRecetadosToolStripMenuItem.Visible = false;
            this.bonosFarmaciaRecetadosToolStripMenuItem.Click += new System.EventHandler(this.bonosFarmaciaRecetadosToolStripMenuItem_Click);
            // 
            // afiliadosQueUsaronPeroNoCompraronToolStripMenuItem
            // 
            this.afiliadosQueUsaronPeroNoCompraronToolStripMenuItem.Name = "afiliadosQueUsaronPeroNoCompraronToolStripMenuItem";
            this.afiliadosQueUsaronPeroNoCompraronToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.afiliadosQueUsaronPeroNoCompraronToolStripMenuItem.Text = "Afiliados que usaron pero no compraron";
            this.afiliadosQueUsaronPeroNoCompraronToolStripMenuItem.Visible = false;
            this.afiliadosQueUsaronPeroNoCompraronToolStripMenuItem.Click += new System.EventHandler(this.afiliadosQueUsaronPeroNoCompraronToolStripMenuItem_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 297);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem consultaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrarResultadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aBMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem altaRolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bajaRolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificarRolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem altaUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bajaUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afiliadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem altaAfiliadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bajaAfiliadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificarAfiliadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem profesionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem altaProfesionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bajaProfesionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificarProfesionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem especialidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem altaEspecialidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bajaEspecialidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificarEspecialidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem planToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem altaPlanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bajaPlanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrarLlegadaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarRolesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarAfiliadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarProfesionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarEspecialidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarPlanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pedidoTurnoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelarAtencionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bonosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comprarBonosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estadisticasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bonosFarmaciaVencidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem especialidadesConCancelacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bonosFarmaciaRecetadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afiliadosQueUsaronPeroNoCompraronToolStripMenuItem;

    }
}