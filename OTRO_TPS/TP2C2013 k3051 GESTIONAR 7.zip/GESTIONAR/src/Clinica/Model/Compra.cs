﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class Compra
    {
        public int afi_ID { get; set; }

        public int afi_Sub_ID { get; set; }

        public int Suma { get; set; }

        public int CantFarmacia { get; set; }

        public int CanConsulta { get; set; }

        public int PlanID { get; set; }

    }
}
