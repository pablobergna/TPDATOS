﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class Medicamento
    {
        public Int32 ID { get; set; }

        public string descripcion { get; set; }
    }
}
