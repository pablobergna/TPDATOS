﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class Agenda
    {
        public Int32 dia { get; set; }

        public string horaInicio { get; set; }

        public string horaFin { get; set; }
    }
}
