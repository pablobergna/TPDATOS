﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class estadistica
    {
        public Int32 mes { get; set; }

        public string dato { get; set; }

        public Int32 cantidad { get; set; }

        public Int32 mes_vencimiento { get; set; }

        public Int32 mes_comprado { get; set; }
    }
}
