﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class Especialidad
    {
        public int Codigo { get; set; }

        public string Descripcion { get; set; }

    }
}
