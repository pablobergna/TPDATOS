﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class Usuario
    {
        public Int32 id { get; set; }
        
        public Int32 rol { get; set; }

        public Int32 user_rel { get; set; }

        public Int32 user_rel_sub { get; set; }

    }
}
