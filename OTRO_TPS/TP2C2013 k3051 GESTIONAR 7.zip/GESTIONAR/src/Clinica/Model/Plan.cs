﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class Plan
    {
       
            public int Codigo { get; set; }

            public string Descripcion { get; set; }

            public int PrecioConsulta { get; set; }

            public int PrecioFarmacia { get; set; }

       
    }
}
