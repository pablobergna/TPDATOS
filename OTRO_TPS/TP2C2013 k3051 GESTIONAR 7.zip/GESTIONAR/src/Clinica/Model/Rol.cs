﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class Rol
    {
        public Int32 id { get; set; }

        public string nombre { get; set; }

        public bool borrado { get; set; }
    }
}
