﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica.Model
{
    public class QueryResult
    {
        public Int32 ID { get; set; }

        public bool correct { get; set; }

        public string mensaje { get; set; }
    }
}
