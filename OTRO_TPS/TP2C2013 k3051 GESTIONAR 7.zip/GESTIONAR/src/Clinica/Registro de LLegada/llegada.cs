﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Clinica.Registro_de_LLegada
{
    public partial class llegada : Form
    {
        public llegada()
        {
            InitializeComponent();
        }
    }
}
