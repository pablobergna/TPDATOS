﻿namespace Clinica.Compra_de_Bono
{
    partial class CompraBonos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBoxAfiliado = new System.Windows.Forms.GroupBox();
            this.textBoxafiSubID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxafiID = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numericUpDownFarmacia = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownConsulta = new System.Windows.Forms.NumericUpDown();
            this.buttonConfirmCantidad = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxTotal = new System.Windows.Forms.GroupBox();
            this.textBoxTotal = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxPlan = new System.Windows.Forms.TextBox();
            this.textBoxPrecioFarmacia = new System.Windows.Forms.TextBox();
            this.textBoxPrecioConsulta = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonComprar = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBoxAfiliado.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFarmacia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownConsulta)).BeginInit();
            this.groupBoxTotal.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.groupBoxAfiliado);
            this.flowLayoutPanel1.Controls.Add(this.groupBox2);
            this.flowLayoutPanel1.Controls.Add(this.groupBoxTotal);
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(1, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(412, 350);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // groupBoxAfiliado
            // 
            this.groupBoxAfiliado.Controls.Add(this.textBoxafiSubID);
            this.groupBoxAfiliado.Controls.Add(this.label4);
            this.groupBoxAfiliado.Controls.Add(this.label6);
            this.groupBoxAfiliado.Controls.Add(this.textBoxafiID);
            this.groupBoxAfiliado.Location = new System.Drawing.Point(3, 3);
            this.groupBoxAfiliado.Name = "groupBoxAfiliado";
            this.groupBoxAfiliado.Size = new System.Drawing.Size(399, 78);
            this.groupBoxAfiliado.TabIndex = 1;
            this.groupBoxAfiliado.TabStop = false;
            this.groupBoxAfiliado.Text = "Ingrese afiliado";
            // 
            // textBoxafiSubID
            // 
            this.textBoxafiSubID.Location = new System.Drawing.Point(197, 28);
            this.textBoxafiSubID.Name = "textBoxafiSubID";
            this.textBoxafiSubID.Size = new System.Drawing.Size(32, 20);
            this.textBoxafiSubID.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(181, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Numero:";
            // 
            // textBoxafiID
            // 
            this.textBoxafiID.Location = new System.Drawing.Point(75, 28);
            this.textBoxafiID.Name = "textBoxafiID";
            this.textBoxafiID.Size = new System.Drawing.Size(100, 20);
            this.textBoxafiID.TabIndex = 15;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.numericUpDownFarmacia);
            this.groupBox2.Controls.Add(this.numericUpDownConsulta);
            this.groupBox2.Controls.Add(this.buttonConfirmCantidad);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(3, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(399, 92);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Seleccion de bonos a comprar";
            // 
            // numericUpDownFarmacia
            // 
            this.numericUpDownFarmacia.Location = new System.Drawing.Point(142, 60);
            this.numericUpDownFarmacia.Name = "numericUpDownFarmacia";
            this.numericUpDownFarmacia.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownFarmacia.TabIndex = 20;
            // 
            // numericUpDownConsulta
            // 
            this.numericUpDownConsulta.Location = new System.Drawing.Point(142, 30);
            this.numericUpDownConsulta.Name = "numericUpDownConsulta";
            this.numericUpDownConsulta.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownConsulta.TabIndex = 19;
            // 
            // buttonConfirmCantidad
            // 
            this.buttonConfirmCantidad.Location = new System.Drawing.Point(318, 63);
            this.buttonConfirmCantidad.Name = "buttonConfirmCantidad";
            this.buttonConfirmCantidad.Size = new System.Drawing.Size(75, 23);
            this.buttonConfirmCantidad.TabIndex = 3;
            this.buttonConfirmCantidad.Text = "Confirmar";
            this.buttonConfirmCantidad.UseVisualStyleBackColor = true;
            this.buttonConfirmCantidad.Click += new System.EventHandler(this.buttonConfirmCantidad_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Cantidad Bonos Farmacia:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Cantidad Bonos Consulta:";
            // 
            // groupBoxTotal
            // 
            this.groupBoxTotal.Controls.Add(this.textBoxTotal);
            this.groupBoxTotal.Controls.Add(this.label8);
            this.groupBoxTotal.Controls.Add(this.textBoxPlan);
            this.groupBoxTotal.Controls.Add(this.textBoxPrecioFarmacia);
            this.groupBoxTotal.Controls.Add(this.textBoxPrecioConsulta);
            this.groupBoxTotal.Controls.Add(this.label7);
            this.groupBoxTotal.Controls.Add(this.label5);
            this.groupBoxTotal.Controls.Add(this.label1);
            this.groupBoxTotal.Controls.Add(this.buttonComprar);
            this.groupBoxTotal.Location = new System.Drawing.Point(3, 185);
            this.groupBoxTotal.Name = "groupBoxTotal";
            this.groupBoxTotal.Size = new System.Drawing.Size(399, 162);
            this.groupBoxTotal.TabIndex = 3;
            this.groupBoxTotal.TabStop = false;
            this.groupBoxTotal.Text = "Confirmar Compra";
            this.groupBoxTotal.Visible = false;
            // 
            // textBoxTotal
            // 
            this.textBoxTotal.Enabled = false;
            this.textBoxTotal.Location = new System.Drawing.Point(186, 97);
            this.textBoxTotal.Name = "textBoxTotal";
            this.textBoxTotal.Size = new System.Drawing.Size(100, 20);
            this.textBoxTotal.TabIndex = 24;
            this.textBoxTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(113, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "TOTAL:";
            // 
            // textBoxPlan
            // 
            this.textBoxPlan.Enabled = false;
            this.textBoxPlan.Location = new System.Drawing.Point(139, 14);
            this.textBoxPlan.Name = "textBoxPlan";
            this.textBoxPlan.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlan.TabIndex = 22;
            // 
            // textBoxPrecioFarmacia
            // 
            this.textBoxPrecioFarmacia.Enabled = false;
            this.textBoxPrecioFarmacia.Location = new System.Drawing.Point(140, 65);
            this.textBoxPrecioFarmacia.Name = "textBoxPrecioFarmacia";
            this.textBoxPrecioFarmacia.Size = new System.Drawing.Size(100, 20);
            this.textBoxPrecioFarmacia.TabIndex = 21;
            this.textBoxPrecioFarmacia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxPrecioConsulta
            // 
            this.textBoxPrecioConsulta.Enabled = false;
            this.textBoxPrecioConsulta.Location = new System.Drawing.Point(140, 39);
            this.textBoxPrecioConsulta.Name = "textBoxPrecioConsulta";
            this.textBoxPrecioConsulta.Size = new System.Drawing.Size(100, 20);
            this.textBoxPrecioConsulta.TabIndex = 20;
            this.textBoxPrecioConsulta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Plan Medico:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Precio por Bono farmacia:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Precio por Bono consulta:";
            // 
            // buttonComprar
            // 
            this.buttonComprar.Location = new System.Drawing.Point(318, 133);
            this.buttonComprar.Name = "buttonComprar";
            this.buttonComprar.Size = new System.Drawing.Size(75, 23);
            this.buttonComprar.TabIndex = 0;
            this.buttonComprar.Text = "Comprar";
            this.buttonComprar.UseVisualStyleBackColor = true;
            this.buttonComprar.Click += new System.EventHandler(this.buttonComprar_Click);
            // 
            // CompraBonos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(415, 357);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "CompraBonos";
            this.Text = "CompraBonos";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBoxAfiliado.ResumeLayout(false);
            this.groupBoxAfiliado.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFarmacia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownConsulta)).EndInit();
            this.groupBoxTotal.ResumeLayout(false);
            this.groupBoxTotal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBoxAfiliado;
        private System.Windows.Forms.TextBox textBoxafiSubID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxafiID;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown numericUpDownFarmacia;
        private System.Windows.Forms.NumericUpDown numericUpDownConsulta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonConfirmCantidad;
        private System.Windows.Forms.GroupBox groupBoxTotal;
        private System.Windows.Forms.TextBox textBoxPlan;
        private System.Windows.Forms.TextBox textBoxPrecioFarmacia;
        private System.Windows.Forms.TextBox textBoxPrecioConsulta;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonComprar;
        private System.Windows.Forms.TextBox textBoxTotal;
        private System.Windows.Forms.Label label8;

    }
}