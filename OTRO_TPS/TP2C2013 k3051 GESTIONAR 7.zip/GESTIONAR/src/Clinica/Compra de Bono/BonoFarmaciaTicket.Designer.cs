﻿namespace Clinica.Compra_de_Bono
{
    partial class BonoFarmaciaTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.labelNumero = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelPlan = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelAfiID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelFechaCompra = new System.Windows.Forms.Label();
            this.labelVencimiento = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(283, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bono N°";
            // 
            // labelNumero
            // 
            this.labelNumero.AutoSize = true;
            this.labelNumero.Location = new System.Drawing.Point(337, 9);
            this.labelNumero.Name = "labelNumero";
            this.labelNumero.Size = new System.Drawing.Size(55, 13);
            this.labelNumero.TabIndex = 1;
            this.labelNumero.Text = "................";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "BONO FARMACIA";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Plan";
            // 
            // labelPlan
            // 
            this.labelPlan.AutoSize = true;
            this.labelPlan.Location = new System.Drawing.Point(109, 42);
            this.labelPlan.Name = "labelPlan";
            this.labelPlan.Size = new System.Drawing.Size(46, 13);
            this.labelPlan.TabIndex = 4;
            this.labelPlan.Text = ".............";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "ID Afiliado";
            // 
            // labelAfiID
            // 
            this.labelAfiID.AutoSize = true;
            this.labelAfiID.Location = new System.Drawing.Point(109, 66);
            this.labelAfiID.Name = "labelAfiID";
            this.labelAfiID.Size = new System.Drawing.Size(46, 13);
            this.labelAfiID.TabIndex = 6;
            this.labelAfiID.Text = ".............";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Fecha de Compra";
            // 
            // labelFechaCompra
            // 
            this.labelFechaCompra.AutoSize = true;
            this.labelFechaCompra.Location = new System.Drawing.Point(115, 97);
            this.labelFechaCompra.Name = "labelFechaCompra";
            this.labelFechaCompra.Size = new System.Drawing.Size(57, 13);
            this.labelFechaCompra.TabIndex = 8;
            this.labelFechaCompra.Text = "xx/xx/xxxx";
            // 
            // labelVencimiento
            // 
            this.labelVencimiento.AutoSize = true;
            this.labelVencimiento.Location = new System.Drawing.Point(323, 97);
            this.labelVencimiento.Name = "labelVencimiento";
            this.labelVencimiento.Size = new System.Drawing.Size(57, 13);
            this.labelVencimiento.TabIndex = 10;
            this.labelVencimiento.Text = "xx/xx/xxxx";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(204, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Fecha de Vencimiento";
            // 
            // BonoFarmaciaTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(411, 120);
            this.Controls.Add(this.labelVencimiento);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelFechaCompra);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelAfiID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelPlan);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelNumero);
            this.Controls.Add(this.label1);
            this.Name = "BonoFarmaciaTicket";
            this.Text = "Bono Farmacia";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelNumero;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelPlan;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelAfiID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelFechaCompra;
        private System.Windows.Forms.Label labelVencimiento;
        private System.Windows.Forms.Label label7;
    }
}