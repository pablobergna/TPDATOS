﻿namespace Clinica_Frba
{
    partial class PantallaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usuarioLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.botonera = new System.Windows.Forms.FlowLayoutPanel();
            this.deslogButton = new System.Windows.Forms.Button();
            this.loginButton = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.botonera.SuspendLayout();
            this.SuspendLayout();
            // 
            // usuarioLabel
            // 
            this.usuarioLabel.AutoSize = true;
            this.usuarioLabel.Location = new System.Drawing.Point(344, 22);
            this.usuarioLabel.Name = "usuarioLabel";
            this.usuarioLabel.Size = new System.Drawing.Size(0, 13);
            this.usuarioLabel.TabIndex = 18;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 9);
            this.button1.Margin = new System.Windows.Forms.Padding(9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 34);
            this.button1.TabIndex = 19;
            this.button1.Text = "Afiliados";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(329, 9);
            this.button3.Margin = new System.Windows.Forms.Padding(9);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(142, 34);
            this.button3.TabIndex = 21;
            this.button3.Text = "Roles";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(489, 9);
            this.button5.Margin = new System.Windows.Forms.Padding(9);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(142, 34);
            this.button5.TabIndex = 23;
            this.button5.Text = "Pedir Turno";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(9, 61);
            this.button6.Margin = new System.Windows.Forms.Padding(9);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(142, 34);
            this.button6.TabIndex = 24;
            this.button6.Text = "Cancelar Atención";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(489, 61);
            this.button7.Margin = new System.Windows.Forms.Padding(9);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(142, 34);
            this.button7.TabIndex = 25;
            this.button7.Text = "Registrar Llegada";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(169, 113);
            this.button8.Margin = new System.Windows.Forms.Padding(9);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(142, 34);
            this.button8.TabIndex = 26;
            this.button8.Text = "Registrar Resultado de Atención";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(329, 113);
            this.button9.Margin = new System.Windows.Forms.Padding(9);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(142, 34);
            this.button9.TabIndex = 27;
            this.button9.Text = "Listados Estadísticos";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(9, 113);
            this.button10.Margin = new System.Windows.Forms.Padding(9);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(142, 34);
            this.button10.TabIndex = 28;
            this.button10.Text = "Generar Receta";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(329, 61);
            this.button11.Margin = new System.Windows.Forms.Padding(9);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(142, 34);
            this.button11.TabIndex = 29;
            this.button11.Text = "Comprar Bono";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(169, 61);
            this.button12.Margin = new System.Windows.Forms.Padding(9);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(142, 34);
            this.button12.TabIndex = 30;
            this.button12.Text = "Registrar Agenda";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(169, 9);
            this.button2.Margin = new System.Windows.Forms.Padding(9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 33);
            this.button2.TabIndex = 31;
            this.button2.Text = "Profesionales";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // botonera
            // 
            this.botonera.AllowDrop = true;
            this.botonera.AutoSize = true;
            this.botonera.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.botonera.Controls.Add(this.button1);
            this.botonera.Controls.Add(this.button2);
            this.botonera.Controls.Add(this.button3);
            this.botonera.Controls.Add(this.button5);
            this.botonera.Controls.Add(this.button6);
            this.botonera.Controls.Add(this.button12);
            this.botonera.Controls.Add(this.button11);
            this.botonera.Controls.Add(this.button7);
            this.botonera.Controls.Add(this.button10);
            this.botonera.Controls.Add(this.button8);
            this.botonera.Controls.Add(this.button9);
            this.botonera.Location = new System.Drawing.Point(12, 72);
            this.botonera.MaximumSize = new System.Drawing.Size(644, 0);
            this.botonera.Name = "botonera";
            this.botonera.Size = new System.Drawing.Size(640, 156);
            this.botonera.TabIndex = 32;
            // 
            // deslogButton
            // 
            this.deslogButton.Location = new System.Drawing.Point(347, 38);
            this.deslogButton.Name = "deslogButton";
            this.deslogButton.Size = new System.Drawing.Size(83, 24);
            this.deslogButton.TabIndex = 17;
            this.deslogButton.Text = "Desloguear";
            this.deslogButton.UseVisualStyleBackColor = true;
            this.deslogButton.Click += new System.EventHandler(this.deslogButton_Click);
            // 
            // loginButton
            // 
            this.loginButton.Location = new System.Drawing.Point(347, 16);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(83, 24);
            this.loginButton.TabIndex = 15;
            this.loginButton.Text = "Loguear";
            this.loginButton.UseVisualStyleBackColor = true;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.Red;
            this.lblTitulo.Location = new System.Drawing.Point(13, 16);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(271, 46);
            this.lblTitulo.TabIndex = 33;
            this.lblTitulo.Text = "Clinica FRBA";
            // 
            // PantallaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(661, 229);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.usuarioLabel);
            this.Controls.Add(this.deslogButton);
            this.Controls.Add(this.loginButton);
            this.Controls.Add(this.botonera);
            this.MinimumSize = new System.Drawing.Size(469, 110);
            this.Name = "PantallaPrincipal";
            this.Text = "Clinica FRBA";
            this.botonera.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label usuarioLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.FlowLayoutPanel botonera;
        private System.Windows.Forms.Button deslogButton;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Label lblTitulo;


    }
}

