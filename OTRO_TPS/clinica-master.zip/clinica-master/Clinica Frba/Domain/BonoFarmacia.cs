﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica_Frba.Domain
{
    class BonoFarmacia : Bono
    {
        DateTime fechaVencimiento { get; set; }
    }
}
