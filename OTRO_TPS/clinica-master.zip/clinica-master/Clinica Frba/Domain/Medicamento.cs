﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clinica_Frba.Domain
{
    public class Medicamento
    {
        public int nroMedicamento { get; set; }
        public string descripcion { get; set; }
        public int cantidad { get; set; }
    }
}
