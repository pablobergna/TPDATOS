﻿namespace Clinica_Frba.Registrar_Agenda
{
    partial class RegistrarAgenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labNombreMedico = new System.Windows.Forms.Label();
            this.botonQuitarMedico = new System.Windows.Forms.Button();
            this.labMedico = new System.Windows.Forms.Label();
            this.labNroMedico = new System.Windows.Forms.Label();
            this.botonBuscarMedico = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.botAddDia = new System.Windows.Forms.Button();
            this.labSaNo = new System.Windows.Forms.Label();
            this.labViNo = new System.Windows.Forms.Label();
            this.labJuNo = new System.Windows.Forms.Label();
            this.labMiNo = new System.Windows.Forms.Label();
            this.labMaNo = new System.Windows.Forms.Label();
            this.labLuNo = new System.Windows.Forms.Label();
            this.labSabado = new System.Windows.Forms.Label();
            this.labViernes = new System.Windows.Forms.Label();
            this.labJueves = new System.Windows.Forms.Label();
            this.labMiercoles = new System.Windows.Forms.Label();
            this.labMartes = new System.Windows.Forms.Label();
            this.labLunes = new System.Windows.Forms.Label();
            this.panelSabado = new System.Windows.Forms.Panel();
            this.botModSa = new System.Windows.Forms.Button();
            this.labSaH = new System.Windows.Forms.Label();
            this.botDelSa = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.labSaD = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panelViernes = new System.Windows.Forms.Panel();
            this.botModVi = new System.Windows.Forms.Button();
            this.labViH = new System.Windows.Forms.Label();
            this.botDelVi = new System.Windows.Forms.Button();
            this.labViD = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panelJueves = new System.Windows.Forms.Panel();
            this.botModJu = new System.Windows.Forms.Button();
            this.labJuH = new System.Windows.Forms.Label();
            this.botDelJu = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.labJuD = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panelMiercoles = new System.Windows.Forms.Panel();
            this.botModMi = new System.Windows.Forms.Button();
            this.labMiH = new System.Windows.Forms.Label();
            this.botDelMi = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.labMiD = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panelMartes = new System.Windows.Forms.Panel();
            this.botModMa = new System.Windows.Forms.Button();
            this.labMaH = new System.Windows.Forms.Label();
            this.botDelMa = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.labMaD = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panelLunes = new System.Windows.Forms.Panel();
            this.botModLu = new System.Windows.Forms.Button();
            this.botDelLu = new System.Windows.Forms.Button();
            this.labLuH = new System.Windows.Forms.Label();
            this.labLuD = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.labAgendaExistente = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panelSabado.SuspendLayout();
            this.panelViernes.SuspendLayout();
            this.panelJueves.SuspendLayout();
            this.panelMiercoles.SuspendLayout();
            this.panelMartes.SuspendLayout();
            this.panelLunes.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labNombreMedico);
            this.groupBox1.Controls.Add(this.botonQuitarMedico);
            this.groupBox1.Controls.Add(this.labMedico);
            this.groupBox1.Controls.Add(this.labNroMedico);
            this.groupBox1.Controls.Add(this.botonBuscarMedico);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(458, 56);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos personales";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // labNombreMedico
            // 
            this.labNombreMedico.AutoSize = true;
            this.labNombreMedico.Location = new System.Drawing.Point(220, 25);
            this.labNombreMedico.Name = "labNombreMedico";
            this.labNombreMedico.Size = new System.Drawing.Size(22, 13);
            this.labNombreMedico.TabIndex = 13;
            this.labNombreMedico.Text = "(...)";
            this.labNombreMedico.Visible = false;
            // 
            // botonQuitarMedico
            // 
            this.botonQuitarMedico.Location = new System.Drawing.Point(144, 21);
            this.botonQuitarMedico.Name = "botonQuitarMedico";
            this.botonQuitarMedico.Size = new System.Drawing.Size(46, 21);
            this.botonQuitarMedico.TabIndex = 12;
            this.botonQuitarMedico.Text = "Quitar";
            this.botonQuitarMedico.UseVisualStyleBackColor = true;
            this.botonQuitarMedico.Visible = false;
            this.botonQuitarMedico.Click += new System.EventHandler(this.botonQuitarMedico_Click);
            // 
            // labMedico
            // 
            this.labMedico.AutoSize = true;
            this.labMedico.Location = new System.Drawing.Point(18, 25);
            this.labMedico.Name = "labMedico";
            this.labMedico.Size = new System.Drawing.Size(62, 13);
            this.labMedico.TabIndex = 8;
            this.labMedico.Text = "Profesional:";
            // 
            // labNroMedico
            // 
            this.labNroMedico.AutoSize = true;
            this.labNroMedico.Location = new System.Drawing.Point(86, 25);
            this.labNroMedico.Name = "labNroMedico";
            this.labNroMedico.Size = new System.Drawing.Size(28, 13);
            this.labNroMedico.TabIndex = 12;
            this.labNroMedico.Text = "(pro)";
            this.labNroMedico.Visible = false;
            // 
            // botonBuscarMedico
            // 
            this.botonBuscarMedico.Location = new System.Drawing.Point(144, 21);
            this.botonBuscarMedico.Name = "botonBuscarMedico";
            this.botonBuscarMedico.Size = new System.Drawing.Size(46, 21);
            this.botonBuscarMedico.TabIndex = 11;
            this.botonBuscarMedico.Text = "Elegir";
            this.botonBuscarMedico.UseVisualStyleBackColor = true;
            this.botonBuscarMedico.Click += new System.EventHandler(this.botonBuscarMedico_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(86, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(41, 20);
            this.textBox1.TabIndex = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.botAddDia);
            this.groupBox2.Controls.Add(this.labSaNo);
            this.groupBox2.Controls.Add(this.labViNo);
            this.groupBox2.Controls.Add(this.labJuNo);
            this.groupBox2.Controls.Add(this.labMiNo);
            this.groupBox2.Controls.Add(this.labMaNo);
            this.groupBox2.Controls.Add(this.labLuNo);
            this.groupBox2.Controls.Add(this.labSabado);
            this.groupBox2.Controls.Add(this.labViernes);
            this.groupBox2.Controls.Add(this.labJueves);
            this.groupBox2.Controls.Add(this.labMiercoles);
            this.groupBox2.Controls.Add(this.labMartes);
            this.groupBox2.Controls.Add(this.labLunes);
            this.groupBox2.Controls.Add(this.panelSabado);
            this.groupBox2.Controls.Add(this.panelViernes);
            this.groupBox2.Controls.Add(this.panelJueves);
            this.groupBox2.Controls.Add(this.panelMiercoles);
            this.groupBox2.Controls.Add(this.panelMartes);
            this.groupBox2.Controls.Add(this.panelLunes);
            this.groupBox2.Location = new System.Drawing.Point(12, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(458, 242);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Días de atención";
            this.groupBox2.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(351, 203);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(93, 23);
            this.button3.TabIndex = 50;
            this.button3.Text = "Cargar período";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // botAddDia
            // 
            this.botAddDia.Location = new System.Drawing.Point(21, 204);
            this.botAddDia.Name = "botAddDia";
            this.botAddDia.Size = new System.Drawing.Size(75, 23);
            this.botAddDia.TabIndex = 49;
            this.botAddDia.Text = "Agregar día";
            this.botAddDia.UseVisualStyleBackColor = true;
            this.botAddDia.Click += new System.EventHandler(this.botAddDia_Click);
            // 
            // labSaNo
            // 
            this.labSaNo.AutoSize = true;
            this.labSaNo.Location = new System.Drawing.Point(58, 179);
            this.labSaNo.Name = "labSaNo";
            this.labSaNo.Size = new System.Drawing.Size(60, 13);
            this.labSaNo.TabIndex = 48;
            this.labSaNo.Text = "no atiende.";
            // 
            // labViNo
            // 
            this.labViNo.AutoSize = true;
            this.labViNo.Location = new System.Drawing.Point(58, 149);
            this.labViNo.Name = "labViNo";
            this.labViNo.Size = new System.Drawing.Size(60, 13);
            this.labViNo.TabIndex = 47;
            this.labViNo.Text = "no atiende.";
            // 
            // labJuNo
            // 
            this.labJuNo.AutoSize = true;
            this.labJuNo.Location = new System.Drawing.Point(57, 118);
            this.labJuNo.Name = "labJuNo";
            this.labJuNo.Size = new System.Drawing.Size(60, 13);
            this.labJuNo.TabIndex = 46;
            this.labJuNo.Text = "no atiende.";
            // 
            // labMiNo
            // 
            this.labMiNo.AutoSize = true;
            this.labMiNo.Location = new System.Drawing.Point(68, 87);
            this.labMiNo.Name = "labMiNo";
            this.labMiNo.Size = new System.Drawing.Size(60, 13);
            this.labMiNo.TabIndex = 45;
            this.labMiNo.Text = "no atiende.";
            // 
            // labMaNo
            // 
            this.labMaNo.AutoSize = true;
            this.labMaNo.Location = new System.Drawing.Point(55, 57);
            this.labMaNo.Name = "labMaNo";
            this.labMaNo.Size = new System.Drawing.Size(60, 13);
            this.labMaNo.TabIndex = 44;
            this.labMaNo.Text = "no atiende.";
            // 
            // labLuNo
            // 
            this.labLuNo.AutoSize = true;
            this.labLuNo.Location = new System.Drawing.Point(51, 26);
            this.labLuNo.Name = "labLuNo";
            this.labLuNo.Size = new System.Drawing.Size(60, 13);
            this.labLuNo.TabIndex = 43;
            this.labLuNo.Text = "no atiende.";
            // 
            // labSabado
            // 
            this.labSabado.AutoSize = true;
            this.labSabado.Location = new System.Drawing.Point(18, 179);
            this.labSabado.Name = "labSabado";
            this.labSabado.Size = new System.Drawing.Size(44, 13);
            this.labSabado.TabIndex = 42;
            this.labSabado.Text = "Sábado";
            // 
            // labViernes
            // 
            this.labViernes.AutoSize = true;
            this.labViernes.Location = new System.Drawing.Point(18, 149);
            this.labViernes.Name = "labViernes";
            this.labViernes.Size = new System.Drawing.Size(42, 13);
            this.labViernes.TabIndex = 41;
            this.labViernes.Text = "Viernes";
            // 
            // labJueves
            // 
            this.labJueves.AutoSize = true;
            this.labJueves.Location = new System.Drawing.Point(18, 118);
            this.labJueves.Name = "labJueves";
            this.labJueves.Size = new System.Drawing.Size(41, 13);
            this.labJueves.TabIndex = 40;
            this.labJueves.Text = "Jueves";
            // 
            // labMiercoles
            // 
            this.labMiercoles.AutoSize = true;
            this.labMiercoles.Location = new System.Drawing.Point(18, 87);
            this.labMiercoles.Name = "labMiercoles";
            this.labMiercoles.Size = new System.Drawing.Size(52, 13);
            this.labMiercoles.TabIndex = 39;
            this.labMiercoles.Text = "Miércoles";
            // 
            // labMartes
            // 
            this.labMartes.AutoSize = true;
            this.labMartes.Location = new System.Drawing.Point(18, 57);
            this.labMartes.Name = "labMartes";
            this.labMartes.Size = new System.Drawing.Size(39, 13);
            this.labMartes.TabIndex = 38;
            this.labMartes.Text = "Martes";
            // 
            // labLunes
            // 
            this.labLunes.AutoSize = true;
            this.labLunes.Location = new System.Drawing.Point(18, 26);
            this.labLunes.Name = "labLunes";
            this.labLunes.Size = new System.Drawing.Size(36, 13);
            this.labLunes.TabIndex = 37;
            this.labLunes.Text = "Lunes";
            // 
            // panelSabado
            // 
            this.panelSabado.Controls.Add(this.botModSa);
            this.panelSabado.Controls.Add(this.labSaH);
            this.panelSabado.Controls.Add(this.botDelSa);
            this.panelSabado.Controls.Add(this.label11);
            this.panelSabado.Controls.Add(this.labSaD);
            this.panelSabado.Controls.Add(this.label12);
            this.panelSabado.Location = new System.Drawing.Point(144, 172);
            this.panelSabado.Name = "panelSabado";
            this.panelSabado.Size = new System.Drawing.Size(300, 25);
            this.panelSabado.TabIndex = 36;
            this.panelSabado.Visible = false;
            // 
            // botModSa
            // 
            this.botModSa.Location = new System.Drawing.Point(237, 3);
            this.botModSa.Name = "botModSa";
            this.botModSa.Size = new System.Drawing.Size(60, 19);
            this.botModSa.TabIndex = 21;
            this.botModSa.Text = "Modificar";
            this.botModSa.UseVisualStyleBackColor = true;
            this.botModSa.Click += new System.EventHandler(this.botModSa_Click);
            // 
            // labSaH
            // 
            this.labSaH.AutoSize = true;
            this.labSaH.Location = new System.Drawing.Point(143, 6);
            this.labSaH.Name = "labSaH";
            this.labSaH.Size = new System.Drawing.Size(22, 13);
            this.labSaH.TabIndex = 19;
            this.labSaH.Text = "(...)";
            // 
            // botDelSa
            // 
            this.botDelSa.Location = new System.Drawing.Point(186, 3);
            this.botDelSa.Name = "botDelSa";
            this.botDelSa.Size = new System.Drawing.Size(45, 19);
            this.botDelSa.TabIndex = 20;
            this.botDelSa.Text = "Quitar";
            this.botDelSa.UseVisualStyleBackColor = true;
            this.botDelSa.Click += new System.EventHandler(this.botDelSa_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(99, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Hasta:";
            // 
            // labSaD
            // 
            this.labSaD.AutoSize = true;
            this.labSaD.Location = new System.Drawing.Point(53, 6);
            this.labSaD.Name = "labSaD";
            this.labSaD.Size = new System.Drawing.Size(22, 13);
            this.labSaD.TabIndex = 18;
            this.labSaD.Text = "(...)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Desde:";
            // 
            // panelViernes
            // 
            this.panelViernes.Controls.Add(this.botModVi);
            this.panelViernes.Controls.Add(this.labViH);
            this.panelViernes.Controls.Add(this.botDelVi);
            this.panelViernes.Controls.Add(this.labViD);
            this.panelViernes.Controls.Add(this.label9);
            this.panelViernes.Controls.Add(this.label10);
            this.panelViernes.Location = new System.Drawing.Point(144, 142);
            this.panelViernes.Name = "panelViernes";
            this.panelViernes.Size = new System.Drawing.Size(300, 25);
            this.panelViernes.TabIndex = 35;
            this.panelViernes.Visible = false;
            // 
            // botModVi
            // 
            this.botModVi.Location = new System.Drawing.Point(237, 4);
            this.botModVi.Name = "botModVi";
            this.botModVi.Size = new System.Drawing.Size(60, 19);
            this.botModVi.TabIndex = 19;
            this.botModVi.Text = "Modificar";
            this.botModVi.UseVisualStyleBackColor = true;
            this.botModVi.Click += new System.EventHandler(this.botModVi_Click);
            // 
            // labViH
            // 
            this.labViH.AutoSize = true;
            this.labViH.Location = new System.Drawing.Point(143, 6);
            this.labViH.Name = "labViH";
            this.labViH.Size = new System.Drawing.Size(22, 13);
            this.labViH.TabIndex = 17;
            this.labViH.Text = "(...)";
            // 
            // botDelVi
            // 
            this.botDelVi.Location = new System.Drawing.Point(186, 4);
            this.botDelVi.Name = "botDelVi";
            this.botDelVi.Size = new System.Drawing.Size(45, 19);
            this.botDelVi.TabIndex = 18;
            this.botDelVi.Text = "Quitar";
            this.botDelVi.UseVisualStyleBackColor = true;
            this.botDelVi.Click += new System.EventHandler(this.botDelVi_Click);
            // 
            // labViD
            // 
            this.labViD.AutoSize = true;
            this.labViD.Location = new System.Drawing.Point(53, 6);
            this.labViD.Name = "labViD";
            this.labViD.Size = new System.Drawing.Size(22, 13);
            this.labViD.TabIndex = 16;
            this.labViD.Text = "(...)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(99, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Hasta:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Desde:";
            // 
            // panelJueves
            // 
            this.panelJueves.Controls.Add(this.botModJu);
            this.panelJueves.Controls.Add(this.labJuH);
            this.panelJueves.Controls.Add(this.botDelJu);
            this.panelJueves.Controls.Add(this.label7);
            this.panelJueves.Controls.Add(this.labJuD);
            this.panelJueves.Controls.Add(this.label8);
            this.panelJueves.Location = new System.Drawing.Point(144, 111);
            this.panelJueves.Name = "panelJueves";
            this.panelJueves.Size = new System.Drawing.Size(300, 25);
            this.panelJueves.TabIndex = 34;
            this.panelJueves.Visible = false;
            // 
            // botModJu
            // 
            this.botModJu.Location = new System.Drawing.Point(237, 3);
            this.botModJu.Name = "botModJu";
            this.botModJu.Size = new System.Drawing.Size(60, 19);
            this.botModJu.TabIndex = 17;
            this.botModJu.Text = "Modificar";
            this.botModJu.UseVisualStyleBackColor = true;
            this.botModJu.Click += new System.EventHandler(this.botModJu_Click);
            // 
            // labJuH
            // 
            this.labJuH.AutoSize = true;
            this.labJuH.Location = new System.Drawing.Point(143, 7);
            this.labJuH.Name = "labJuH";
            this.labJuH.Size = new System.Drawing.Size(22, 13);
            this.labJuH.TabIndex = 15;
            this.labJuH.Text = "(...)";
            // 
            // botDelJu
            // 
            this.botDelJu.Location = new System.Drawing.Point(186, 3);
            this.botDelJu.Name = "botDelJu";
            this.botDelJu.Size = new System.Drawing.Size(45, 19);
            this.botDelJu.TabIndex = 16;
            this.botDelJu.Text = "Quitar";
            this.botDelJu.UseVisualStyleBackColor = true;
            this.botDelJu.Click += new System.EventHandler(this.botDelJu_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(99, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Hasta:";
            // 
            // labJuD
            // 
            this.labJuD.AutoSize = true;
            this.labJuD.Location = new System.Drawing.Point(53, 6);
            this.labJuD.Name = "labJuD";
            this.labJuD.Size = new System.Drawing.Size(22, 13);
            this.labJuD.TabIndex = 14;
            this.labJuD.Text = "(...)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Desde:";
            // 
            // panelMiercoles
            // 
            this.panelMiercoles.Controls.Add(this.botModMi);
            this.panelMiercoles.Controls.Add(this.labMiH);
            this.panelMiercoles.Controls.Add(this.botDelMi);
            this.panelMiercoles.Controls.Add(this.label5);
            this.panelMiercoles.Controls.Add(this.labMiD);
            this.panelMiercoles.Controls.Add(this.label6);
            this.panelMiercoles.Location = new System.Drawing.Point(144, 80);
            this.panelMiercoles.Name = "panelMiercoles";
            this.panelMiercoles.Size = new System.Drawing.Size(300, 25);
            this.panelMiercoles.TabIndex = 33;
            this.panelMiercoles.Visible = false;
            // 
            // botModMi
            // 
            this.botModMi.Location = new System.Drawing.Point(237, 3);
            this.botModMi.Name = "botModMi";
            this.botModMi.Size = new System.Drawing.Size(60, 19);
            this.botModMi.TabIndex = 15;
            this.botModMi.Text = "Modificar";
            this.botModMi.UseVisualStyleBackColor = true;
            this.botModMi.Click += new System.EventHandler(this.botModMi_Click);
            // 
            // labMiH
            // 
            this.labMiH.AutoSize = true;
            this.labMiH.Location = new System.Drawing.Point(143, 6);
            this.labMiH.Name = "labMiH";
            this.labMiH.Size = new System.Drawing.Size(22, 13);
            this.labMiH.TabIndex = 13;
            this.labMiH.Text = "(...)";
            // 
            // botDelMi
            // 
            this.botDelMi.Location = new System.Drawing.Point(186, 3);
            this.botDelMi.Name = "botDelMi";
            this.botDelMi.Size = new System.Drawing.Size(45, 19);
            this.botDelMi.TabIndex = 14;
            this.botDelMi.Text = "Quitar";
            this.botDelMi.UseVisualStyleBackColor = true;
            this.botDelMi.Click += new System.EventHandler(this.botDelMi_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(99, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Hasta:";
            // 
            // labMiD
            // 
            this.labMiD.AutoSize = true;
            this.labMiD.Location = new System.Drawing.Point(53, 6);
            this.labMiD.Name = "labMiD";
            this.labMiD.Size = new System.Drawing.Size(22, 13);
            this.labMiD.TabIndex = 12;
            this.labMiD.Text = "(...)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Desde:";
            // 
            // panelMartes
            // 
            this.panelMartes.Controls.Add(this.botModMa);
            this.panelMartes.Controls.Add(this.labMaH);
            this.panelMartes.Controls.Add(this.botDelMa);
            this.panelMartes.Controls.Add(this.label3);
            this.panelMartes.Controls.Add(this.labMaD);
            this.panelMartes.Controls.Add(this.label4);
            this.panelMartes.Location = new System.Drawing.Point(144, 50);
            this.panelMartes.Name = "panelMartes";
            this.panelMartes.Size = new System.Drawing.Size(300, 25);
            this.panelMartes.TabIndex = 32;
            this.panelMartes.Visible = false;
            // 
            // botModMa
            // 
            this.botModMa.Location = new System.Drawing.Point(237, 3);
            this.botModMa.Name = "botModMa";
            this.botModMa.Size = new System.Drawing.Size(60, 19);
            this.botModMa.TabIndex = 13;
            this.botModMa.Text = "Modificar";
            this.botModMa.UseVisualStyleBackColor = true;
            this.botModMa.Click += new System.EventHandler(this.botModMa_Click);
            // 
            // labMaH
            // 
            this.labMaH.AutoSize = true;
            this.labMaH.Location = new System.Drawing.Point(143, 6);
            this.labMaH.Name = "labMaH";
            this.labMaH.Size = new System.Drawing.Size(22, 13);
            this.labMaH.TabIndex = 11;
            this.labMaH.Text = "(...)";
            // 
            // botDelMa
            // 
            this.botDelMa.Location = new System.Drawing.Point(186, 3);
            this.botDelMa.Name = "botDelMa";
            this.botDelMa.Size = new System.Drawing.Size(45, 19);
            this.botDelMa.TabIndex = 12;
            this.botDelMa.Text = "Quitar";
            this.botDelMa.UseVisualStyleBackColor = true;
            this.botDelMa.Click += new System.EventHandler(this.botDelMa_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(99, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Hasta:";
            // 
            // labMaD
            // 
            this.labMaD.AutoSize = true;
            this.labMaD.Location = new System.Drawing.Point(53, 6);
            this.labMaD.Name = "labMaD";
            this.labMaD.Size = new System.Drawing.Size(22, 13);
            this.labMaD.TabIndex = 10;
            this.labMaD.Text = "(...)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Desde:";
            // 
            // panelLunes
            // 
            this.panelLunes.Controls.Add(this.botModLu);
            this.panelLunes.Controls.Add(this.botDelLu);
            this.panelLunes.Controls.Add(this.labLuH);
            this.panelLunes.Controls.Add(this.labLuD);
            this.panelLunes.Controls.Add(this.label2);
            this.panelLunes.Controls.Add(this.label1);
            this.panelLunes.Location = new System.Drawing.Point(144, 19);
            this.panelLunes.Name = "panelLunes";
            this.panelLunes.Size = new System.Drawing.Size(300, 25);
            this.panelLunes.TabIndex = 31;
            this.panelLunes.Visible = false;
            // 
            // botModLu
            // 
            this.botModLu.Location = new System.Drawing.Point(237, 3);
            this.botModLu.Name = "botModLu";
            this.botModLu.Size = new System.Drawing.Size(60, 19);
            this.botModLu.TabIndex = 11;
            this.botModLu.Text = "Modificar";
            this.botModLu.UseVisualStyleBackColor = true;
            this.botModLu.Click += new System.EventHandler(this.botModLu_Click);
            // 
            // botDelLu
            // 
            this.botDelLu.Location = new System.Drawing.Point(186, 3);
            this.botDelLu.Name = "botDelLu";
            this.botDelLu.Size = new System.Drawing.Size(45, 19);
            this.botDelLu.TabIndex = 10;
            this.botDelLu.Text = "Quitar";
            this.botDelLu.UseVisualStyleBackColor = true;
            this.botDelLu.Click += new System.EventHandler(this.botDelLu_Click);
            // 
            // labLuH
            // 
            this.labLuH.AutoSize = true;
            this.labLuH.Location = new System.Drawing.Point(143, 6);
            this.labLuH.Name = "labLuH";
            this.labLuH.Size = new System.Drawing.Size(22, 13);
            this.labLuH.TabIndex = 9;
            this.labLuH.Text = "(...)";
            // 
            // labLuD
            // 
            this.labLuD.AutoSize = true;
            this.labLuD.Location = new System.Drawing.Point(53, 6);
            this.labLuD.Name = "labLuD";
            this.labLuD.Size = new System.Drawing.Size(22, 13);
            this.labLuD.TabIndex = 8;
            this.labLuD.Text = "(...)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(99, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Hasta:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Desde:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(381, 335);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "Volver";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // labAgendaExistente
            // 
            this.labAgendaExistente.AutoSize = true;
            this.labAgendaExistente.Location = new System.Drawing.Point(30, 71);
            this.labAgendaExistente.Name = "labAgendaExistente";
            this.labAgendaExistente.Size = new System.Drawing.Size(391, 13);
            this.labAgendaExistente.TabIndex = 15;
            this.labAgendaExistente.Text = "Usted ya ha registrado una agenda. La agenda profesional no puede modificarse.";
            this.labAgendaExistente.Visible = false;
            // 
            // RegistrarAgenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 367);
            this.Controls.Add(this.labAgendaExistente);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Name = "RegistrarAgenda";
            this.Text = "Registrar Agenda";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panelSabado.ResumeLayout(false);
            this.panelSabado.PerformLayout();
            this.panelViernes.ResumeLayout(false);
            this.panelViernes.PerformLayout();
            this.panelJueves.ResumeLayout(false);
            this.panelJueves.PerformLayout();
            this.panelMiercoles.ResumeLayout(false);
            this.panelMiercoles.PerformLayout();
            this.panelMartes.ResumeLayout(false);
            this.panelMartes.PerformLayout();
            this.panelLunes.ResumeLayout(false);
            this.panelLunes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button botonQuitarMedico;
        private System.Windows.Forms.Label labMedico;
        private System.Windows.Forms.Label labNroMedico;
        private System.Windows.Forms.Button botonBuscarMedico;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelLunes;
        private System.Windows.Forms.Panel panelSabado;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelViernes;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panelJueves;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panelMiercoles;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panelMartes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labSabado;
        private System.Windows.Forms.Label labViernes;
        private System.Windows.Forms.Label labJueves;
        private System.Windows.Forms.Label labMiercoles;
        private System.Windows.Forms.Label labMartes;
        private System.Windows.Forms.Label labLunes;
        private System.Windows.Forms.Label labSaH;
        private System.Windows.Forms.Label labSaD;
        private System.Windows.Forms.Label labViH;
        private System.Windows.Forms.Label labViD;
        private System.Windows.Forms.Label labJuH;
        private System.Windows.Forms.Label labJuD;
        private System.Windows.Forms.Label labMiH;
        private System.Windows.Forms.Label labMiD;
        private System.Windows.Forms.Label labMaH;
        private System.Windows.Forms.Label labMaD;
        private System.Windows.Forms.Label labLuH;
        private System.Windows.Forms.Label labLuD;
        private System.Windows.Forms.Label labSaNo;
        private System.Windows.Forms.Label labViNo;
        private System.Windows.Forms.Label labJuNo;
        private System.Windows.Forms.Label labMiNo;
        private System.Windows.Forms.Label labMaNo;
        private System.Windows.Forms.Label labLuNo;
        private System.Windows.Forms.Button botModSa;
        private System.Windows.Forms.Button botDelSa;
        private System.Windows.Forms.Button botModVi;
        private System.Windows.Forms.Button botDelVi;
        private System.Windows.Forms.Button botModJu;
        private System.Windows.Forms.Button botDelJu;
        private System.Windows.Forms.Button botModMi;
        private System.Windows.Forms.Button botDelMi;
        private System.Windows.Forms.Button botModMa;
        private System.Windows.Forms.Button botDelMa;
        private System.Windows.Forms.Button botModLu;
        private System.Windows.Forms.Button botDelLu;
        private System.Windows.Forms.Button botAddDia;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label labNombreMedico;
        private System.Windows.Forms.Label labAgendaExistente;
    }
}